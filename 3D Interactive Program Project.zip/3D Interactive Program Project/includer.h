#pragma once
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <random>
#include <math.h>
#include <map>
#include <Windows.h>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>

#pragma comment(lib, "Winmm.lib")